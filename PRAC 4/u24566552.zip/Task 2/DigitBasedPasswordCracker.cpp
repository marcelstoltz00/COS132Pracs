#include "DigitBasedPasswordCracker.h"


int crackPassswordPerDigit(int password, int numDigits){
    // Implement here
    return crackDigit(password,0,numDigits,0);

}

// Modified processDigitGuess function
int processDigitGuess(int password, int guessedDigit, int numDigitsLeftToGuess, int currentPasswordGuess) {
    // Implement here
    int value ;
  (((password/(10^guessedDigit))%10)==guessedDigit)?
        (value=crackDigit(password,guessedDigit,numDigitsLeftToGuess-1,currentPasswordGuess)
        ,currentPasswordGuess=currentPasswordGuess+guessedDigit*(10)^guessedDigit):
        ( value=crackDigit(password,guessedDigit+1,numDigitsLeftToGuess,currentPasswordGuess));
return value;

}


// Modified crackDigit function to use processDigitGuess
int crackDigit(int password, int guessedDigit, int numDigitsLeftToGuess, int currentPasswordGuess) {
    // Implement here
    printCurrentGuess(password,guessedDigit,numDigitsLeftToGuess,currentPasswordGuess);
    (numDigitsLeftToGuess=0)?(password=currentPasswordGuess):(password=processDigitGuess(password,guessedDigit,numDigitsLeftToGuess,currentPasswordGuess));
    return password;
}
