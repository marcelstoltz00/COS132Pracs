#include "RangeBasedPasswordCracker.h"

int decideAndSearch(int guess, int password, int low, int high) {
    // Implement here
return (isLessThan(guess,password)?(crackPassword(guess+1,high,password)):(crackPassword(guess,guess-1,password)));


}


int crackPassword(int low, int high, int password) {
    // Implement here
    int guess = (low+high)/2;
    printGuess(guess);
            isEqual(guess,password)?(password=foundPassword(guess)):(password=decideAndSearch(guess,password,low,high));
    return password;
        
}
