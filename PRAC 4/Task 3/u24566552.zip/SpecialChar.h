#ifndef SPECIALCHAR_H
#define SPECIALCHAR_H

char findSpecialChar(char target, int current = 1);

#endif