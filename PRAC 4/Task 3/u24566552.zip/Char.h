#ifndef Char_h
#define Char_h

char findNextChar(char current);
char findChar(char target, char current = 'a');

#endif