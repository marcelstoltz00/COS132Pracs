#ifndef Total_h
#define Total_h

double subTotal(int , double , int , double );
double pracSubTotal(double , double , int , double , int , double , int  );

double quizSubTotal(double , double , int , double , int , double , int , double , int  );

double getResult(double , double );

#endif