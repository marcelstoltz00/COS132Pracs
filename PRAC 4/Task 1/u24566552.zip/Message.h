#ifndef Message_h
#define Message_h

void printPassMessage();
void printFailMessage();
void printDistinction();
void handlePass(double);



#endif