#ifndef Calculate_h
#define Calculate_h
double calculateContribution(double , int , double );
double calculateIndividualWeight(double , int );
#endif 
