#include "Comparisons.h"

bool isEqual(int a, int b) {
    // Implement here
    return (a==b);
}

bool isLessThan(int a, int b) {
    // Implement here
    return (a<b);
}

bool isGreaterThan(int a, int b){
    // Implement here
    return (a>b);
    
}