#ifndef Comparisons_h
#define Comparisons_h
// Comparison functions
bool isEqual(int a, int b);

bool isLessThan(int a, int b);

bool isGreaterThan(int a, int b);

#endif